# CONTRIBUTING

## New features / bugfixes

New features are only merged against the master branch, other branches are considered
as stable, and will only accept bugfixes / small enhancements.

## Running the testsuite

Please make sure all tests pass before submitting a PR, you can also enable the
Travis hook on your fork.