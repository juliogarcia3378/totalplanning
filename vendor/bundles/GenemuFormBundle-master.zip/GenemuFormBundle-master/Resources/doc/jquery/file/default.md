# Default configuration File Field:

``` yml
# app/config/config.yml
genemu_form:
    file:
        enabled:    true
        cancel_img: '/bundles/genemuform/images/cancel.png'
        folder:     '/upload'
```
