# Default configuration Tinymce Field:

``` yml
# app/config/config.yml
genemu_form:
    tinymce:
        enabled: true
        theme:   advanced
```
