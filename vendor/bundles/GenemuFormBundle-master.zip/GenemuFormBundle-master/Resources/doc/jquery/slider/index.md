# JQuerySlider Field ([view demo](http://jqueryui.com/demos/slider/))

## Default Usage:

``` php
<?php
// ...
public function buildForm(FormBuilder $builder, array $options)
{
    $builder
        // ...
        ->add('price', 'genemu_jqueryslider');
}
```
